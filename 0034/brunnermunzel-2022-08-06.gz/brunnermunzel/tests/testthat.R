library(testthat)
library(brunnermunzel)

test_check("brunnermunzel")
