# comment
add several outputs and an option
* return the sample estimate in brunnermunzel.permutation.test
* return 'P(X<Y) - P(X>Y)' as the sample estimate
   when setting 'est = "difference"' (new option)

Possibly mis-spelled words in DESCRIPTION:
  Brunner (3:19, 9:41, 10:14, 12:34, 14:21)
  Munzel (3:27, 9:49, 10:22, 12:46)
  Neubert (14:9)

